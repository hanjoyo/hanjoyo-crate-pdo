Main Authors
============

Bernd Dorn (@dobe) <bernddorn@gmail.com>
Christian Haudum (@chaudum) <christian.haudum@gmail.com>
Sebastian Utz (@seut) <su@rtme.net>
Antoine Hedgecock (@macnibblet) <antoine.hedgecock@gmail.com>
Marco Pivetta (@Ocramius) <ocramius@gmail.com>

Code Contributors
=================

Paweł Krzaczkowski (@krzaczek) <pawel@freshmind.pl>

Note: (@user) means a github user name.
