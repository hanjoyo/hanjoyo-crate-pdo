============
Contributing
============

Thank you for your interest in contributing.

Please see the CrateDB `contribution guide`_ for more information. Everything in
the CrateDB contribution guide applies to this repository.

.. _contribution guide: https://github.com/crate/crate/blob/master/CONTRIBUTING.rst
