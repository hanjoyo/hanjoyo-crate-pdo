.. _appendices:

==========
Appendices
==========

Supplementary information for the CrateDB PDO Driver.

.. rubric:: Table of Contents

.. toctree::
   :maxdepth: 2

   data-types
   compatibility
